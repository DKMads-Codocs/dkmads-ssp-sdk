package com.dkmads.ssp

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Build
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.io.ByteArrayInputStream
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * Internal fullscreen presenter for [DKMadsInterstitialAd]. Not intended for direct use.
 */
class DKMadsInterstitialActivity : Activity() {

    data class Callbacks(
        val onPresented: () -> Unit = {},
        val onDismissed: () -> Unit = {},
        val onRenderFailed: (String) -> Unit = {},
        val onCompleted: (Boolean) -> Unit = {},
    )

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var adUnitId: String
    private lateinit var ad: Ad
    private var callbacks: Callbacks = Callbacks()

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var imageView: ImageView
    private lateinit var videoContainer: FrameLayout
    private var nativeVideo: DKMadsNativeVideoSurface? = null
    private var videoTracker: VideoTracker? = null
    private var viewabilityStarted = false
    private var ctaButton: Button? = null
    private var skipButton: Button? = null
    private var skipRunnable: Runnable? = null
    private var completionSignaled = false
    private var webContentReady = false
    private var mraid: DKMadsMraidController? = null
    private var omidSession: DKMadsOmidSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = DKMadsCreativeChrome.letterboxBgColor
            window.navigationBarColor = DKMadsCreativeChrome.letterboxBgColor
        }
        adUnitId = intent.getStringExtra(EXTRA_AD_UNIT_ID).orEmpty()
        val payload = pendingPayload
        if (payload == null || adUnitId.isBlank()) {
            finish()
            return
        }
        ad = payload.first
        callbacks = payload.second
        pendingPayload = null

        root = FrameLayout(this).apply {
            setBackgroundColor(DKMadsCreativeChrome.letterboxBgColor)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
        setContentView(root)
        setupChrome()
        val preferImage = ad.renderModeHint == "image" && ad.creativeUrl.isNotBlank()
        when {
            preferImage -> presentImage()
            !ad.playableVideoUrl.isNullOrBlank() -> presentVideo()
            ad.hasVideoRenderableContent || ad.isHtml5 || ad.adm.isNotBlank() -> presentWeb()
            ad.creativeUrl.isNotBlank() -> presentImage()
            else -> failAndFinish("Interstitial creative is not video, image, or HTML5")
        }
        callbacks.onPresented()
    }

    override fun onDestroy() {
        stopViewability()
        removeVideoClickThroughCta()
        cancelVideoSkip()
        videoTracker?.stop()
        videoTracker = null
        nativeVideo?.release()
        nativeVideo = null
        omidSession?.finish()
        omidSession = null
        scope.cancel()
        super.onDestroy()
    }

    private fun setupChrome() {
        val close = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setColorFilter(Color.WHITE)
            setBackgroundColor(0x73000000.toInt())
            contentDescription = "Close"
            setOnClickListener { closeFromUser() }
        }
        val closeLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END,
        ).apply {
            val m = (12 * resources.displayMetrics.density).toInt()
            setMargins(m, m, m, m)
        }
        root.addView(close, closeLp)

        webView = WebView(this).apply {
            DKMadsBannerCreativeLayout.configureWebViewForRichMedia(settings)
            visibility = View.GONE
        }
        imageView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
            setOnClickListener { onStaticClicked() }
        }
        videoContainer = FrameLayout(this).apply {
            visibility = View.GONE
        }
        val contentLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT,
        )
        root.addView(videoContainer, 0, contentLp)
        root.addView(webView, 0, contentLp)
        root.addView(imageView, 0, contentLp)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun presentWeb() {
        webContentReady = false
        webView.visibility = View.VISIBLE
        val html5Entry = DKMadsBannerCreativeLayout.resolveHtml5EntryUrl(ad)
        DKMadsBannerCreativeLayout.configureWebViewForRichMedia(webView.settings)
        val mraidController = if (ad.isMraidCreative) {
            DKMadsMraidController(webView, "interstitial", interstitialMraidHost()).also {
                it.attach()
                mraid = it
            }
        } else {
            null
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                mraidController?.injectScript()
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (mraidController != null && request?.url?.lastPathSegment == "mraid.js") {
                    return WebResourceResponse(
                        "application/javascript",
                        "UTF-8",
                        ByteArrayInputStream(DKMadsMraidScript.JS.toByteArray(Charsets.UTF_8)),
                    )
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                webContentReady = true
                val injectScript = if (html5Entry != null) {
                    DKMadsBannerCreativeLayout.HTML5_FULLSCREEN_VIEWPORT_SCRIPT
                } else {
                    DKMadsBannerCreativeLayout.FULLSCREEN_VIEWPORT_INJECTION_SCRIPT
                }
                view?.evaluateJavascript(injectScript, null)
                DKMadsBannerCreativeLayout.fullscreenClickThroughInjectionScript(ad.clickUrl)
                    ?.let { view?.evaluateJavascript(it, null) }
                mraidController?.notifyReady()
                mraidController?.setViewable(true)
                if (omidSession == null && DKMadsOmid.isAvailable) {
                    omidSession = DKMadsOmid.provider?.createHtmlDisplaySession(this@DKMadsInterstitialActivity, webView)?.also {
                        it.start()
                        it.signalLoaded()
                    }
                }
                startViewability()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return handleWebClickThrough(request?.url, request?.isForMainFrame == true)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return handleWebClickThrough(url?.let { Uri.parse(it) }, true)
            }
        }
        when {
            html5Entry != null -> webView.loadUrl(html5Entry)
            ad.adm.isNotBlank() -> webView.loadDataWithBaseURL(
                "https://ssp.dkmads.com",
                DKMadsBannerCreativeLayout.htmlForFullscreen(ad.adm),
                "text/html",
                "UTF-8",
                null,
            )
            else -> failAndFinish("HTML5 interstitial missing adm or html5_entry_url")
        }
    }

    private fun presentImage() {
        imageView.visibility = View.VISIBLE
        scope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                runCatching {
                    URL(ad.creativeUrl).openStream().use { BitmapFactory.decodeStream(it) }
                }.getOrNull()
            }
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap)
                startOmidNativeSession()
                startViewability()
            } else {
                failAndFinish("Failed to load interstitial image")
            }
        }
    }

    private fun presentVideo() {
        val url = ad.playableVideoUrl ?: return failAndFinish("Video fill missing video_url")
        videoContainer.visibility = View.VISIBLE
        val muted = DKMadsVideoChrome.defaultPlaybackMuted(
            ad.unitFormat,
            ad.placementContext,
            ad.videoTemplate,
        )
        nativeVideo = DKMadsNativeVideoSurface(this, videoContainer).also { surface ->
            surface.play(
                url = url,
                autoplay = true,
                muted = muted,
                callbacks = object : DKMadsNativeVideoSurface.Callbacks {
                    override fun onReady(durationMs: Long) {
            videoTracker = SSPSDK.trackVideoLifecycle(
                adUnitId = adUnitId,
                campaignId = ad.campaignId,
                creativeId = ad.creativeId ?: ad.id,
                            containerView = videoContainer,
                            durationMsProvider = { surface.durationMs() },
                            currentPositionMsProvider = { surface.currentPositionMs() },
                            isPlayingProvider = { surface.isPlaying() },
                            skippable = ad.skippable ?: true,
                            eventListener = { event, _ -> forwardOmidVideoEvent(event) },
                        )
                        attachVideoClickThroughCta()
                        scheduleVideoSkip()
                        startOmidVideoSession(durationMs, muted)
                        startViewability()
                    }

                    override fun onComplete() {
                        omidSession?.signalVideoComplete()
                        signalCompletion(skipped = false)
                        finish()
                    }

                    override fun onError(message: String) {
                        failAndFinish(message)
                    }
                },
            )
        }
    }

    private fun attachVideoClickThroughCta() {
        removeVideoClickThroughCta()
        val style = DKMadsClickThroughCta.styleForAd(ad.videoTemplate, ad.ctaPosition)
        ctaButton = DKMadsClickThroughCta.attach(
            parent = root,
            clickUrl = ad.clickUrl,
            style = style,
            label = ad.ctaLabel,
            onClickThrough = { recordClick() },
        )
    }

    private fun removeVideoClickThroughCta() {
        ctaButton?.let { root.removeView(it) }
        ctaButton = null
    }

    private fun scheduleVideoSkip() {
        if (ad.skippable == false) return
        cancelVideoSkip()
        val skipAfterSec = ad.skipAfterSec?.takeIf { it >= 0 } ?: 5.0
        val runnable = Runnable {
            if (skipButton != null) return@Runnable
            val btn = Button(this).apply {
                text = "Skip"
                setTextColor(Color.WHITE)
                setBackgroundColor(0x8C000000.toInt())
                setOnClickListener {
                    videoTracker?.markUserSkipped()
                    nativeVideo?.stop()
                    omidSession?.signalVideoSkipped()
                    emitVideoSkip()
                    signalCompletion(skipped = true)
                    finish()
                }
            }
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END,
            ).apply {
                val m = (56 * resources.displayMetrics.density).toInt()
                setMargins(m, m, m, m)
            }
            root.addView(btn, lp)
            skipButton = btn
        }
        skipRunnable = runnable
        root.postDelayed(runnable, (skipAfterSec * 1000).toLong())
    }

    private fun cancelVideoSkip() {
        skipRunnable?.let { root.removeCallbacks(it) }
        skipRunnable = null
        skipButton?.let { root.removeView(it) }
        skipButton = null
    }

    private fun emitVideoSkip() {
        val metadata = mapOf("skippable" to true)
        TelemetryManager.shared.trackEvent(
            "video_skip",
            mapOf(
                "ad_unit_id" to adUnitId,
                "campaign_id" to ad.campaignId,
                "creative_id" to (ad.creativeId ?: ad.id),
                "metadata" to metadata,
            ),
        )
    }

    private fun startOmidVideoSession(durationMs: Long, muted: Boolean) {
        if (omidSession != null || !DKMadsOmid.isAvailable) return
        omidSession = DKMadsOmid.provider
            ?.createVideoSession(this, videoContainer, ad.omidVerifications)
            ?.also {
                it.start()
                it.signalLoaded()
                it.signalVideoStart(durationMs / 1000f, if (muted) 0f else 1f)
            }
    }

    private fun forwardOmidVideoEvent(event: String) {
        val session = omidSession ?: return
        when (event) {
            "video_25" -> session.signalVideoFirstQuartile()
            "video_50" -> session.signalVideoMidpoint()
            "video_75" -> session.signalVideoThirdQuartile()
            "video_pause" -> session.signalVideoPaused()
            "video_resume" -> session.signalVideoResumed()
        }
    }

    private fun interstitialMraidHost(): DKMadsMraidHost = object : DKMadsMraidHost {
        override fun onMraidOpen(url: String) {
            recordClick()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        override fun onMraidClose() {
            closeFromUser()
        }
    }

    private fun handleWebClickThrough(uri: Uri?, isMainFrame: Boolean): Boolean {
        if (!ClickThroughNavigation.shouldOpenLandingUri(uri, isMainFrame, webContentReady)) return false
        recordClick()
        startActivity(Intent(Intent.ACTION_VIEW, uri))
        return true
    }

    private fun onStaticClicked() {
        recordClick()
        val click = ad.clickUrl
        if (click.isNotBlank()) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(click)))
        }
    }

    private fun recordClick() {
        SSPSDK.recordAdClick(
            adUnitId,
            ad.id,
            campaignId = ad.campaignId,
            creativeId = ad.creativeId,
            dspSource = ad.dsp,
        )
    }

    private fun startOmidNativeSession() {
        if (omidSession != null || !DKMadsOmid.isAvailable) return
        val host = if (imageView.visibility == View.VISIBLE) imageView else root
        omidSession = DKMadsOmid.provider
            ?.createNativeDisplaySession(this, host, ad.omidVerifications)
            ?.also {
                it.start()
                it.signalLoaded()
            }
    }

    private fun startViewability() {
        if (viewabilityStarted || root.width <= 0 || root.height <= 0) return
        // Native video tracker emits `video_viewable` using 50%/2s.
        // Do not double-count with display viewability for the same video impression.
        if (videoTracker != null) return
        viewabilityStarted = true
        if (!ad.impressionRecorded) {
            SSPSDK.recordAdImpression(
                adUnitId = adUnitId,
                adId = ad.id,
                campaignId = ad.campaignId,
                creativeId = ad.creativeId,
                dspSource = ad.dsp,
                reason = ad.reason,
            )
        }
        SSPSDK.attachBannerViewability(
            adUnitId = adUnitId,
            container = root,
            campaignId = ad.campaignId,
            creativeId = ad.creativeId ?: ad.id,
            minExposureTimeMs = if (ad.isVideo) 2_000 else 1_000,
        )
        omidSession?.signalImpression()
    }

    private fun stopViewability() {
        if (viewabilityStarted) {
            SSPSDK.detachBannerViewability(adUnitId)
            viewabilityStarted = false
        }
    }

    private fun failAndFinish(message: String) {
        callbacks.onRenderFailed(message)
        finish()
    }

    private fun signalCompletion(skipped: Boolean) {
        if (completionSignaled) return
        completionSignaled = true
        callbacks.onCompleted(skipped)
    }

    private fun closeFromUser() {
        if (ad.isVideo) {
            signalCompletion(skipped = true)
        }
        finish()
    }

    override fun finish() {
        callbacks.onDismissed()
        super.finish()
    }

    companion object {
        private const val EXTRA_AD_UNIT_ID = "dkmads_interstitial_ad_unit_id"
        private var pendingPayload: Pair<Ad, Callbacks>? = null

        fun present(context: Context, adUnitId: String, ad: Ad, callbacks: Callbacks) {
            pendingPayload = ad to callbacks
            val intent = Intent(context, DKMadsInterstitialActivity::class.java).apply {
                putExtra(EXTRA_AD_UNIT_ID, adUnitId)
                if (context !is Activity) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
        }
    }
}
